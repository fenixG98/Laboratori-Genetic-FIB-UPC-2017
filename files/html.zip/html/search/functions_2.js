var searchData=
[
  ['es_5fparcial',['es_parcial',['../classarbre__parcial.html#a3e331e18b78b406f135a96a2f79dca62',1,'arbre_parcial']]],
  ['escriure',['escriure',['../classarbre__parcial.html#a37a9cfea89c8a2a44c05ddaa8eb9aa5d',1,'arbre_parcial::escriure()'],['../classc__individu.html#a9dd5b8474c2befb795c0556a35df38ec',1,'c_individu::escriure()'],['../classc__poblacio.html#a2a4943a18f7a0012a929f3c1f26858bb',1,'c_poblacio::escriure()']]],
  ['escriure_5farbre_5fgenealogic',['escriure_arbre_genealogic',['../classc__poblacio.html#ae4ff49052b87cf9c5fe01368f0ccbaea',1,'c_poblacio']]],
  ['escriure_5farbre_5fstring',['escriure_arbre_string',['../classarbre__parcial.html#adbf1fdd0d7a8fd43c8288d7c09bcf3de',1,'arbre_parcial']]],
  ['existeix_5findividu',['existeix_individu',['../classc__poblacio.html#a80a5eef13905ea1173ab460f30acb720',1,'c_poblacio']]]
];
