var searchData=
[
  ['te_5fpares',['te_pares',['../classc__individu.html#ae738cfb0e89c18c1e989448f947299b6',1,'c_individu']]]
];
