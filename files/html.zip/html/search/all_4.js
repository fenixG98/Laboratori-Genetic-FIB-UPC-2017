var searchData=
[
  ['ind',['ind',['../structc__poblacio_1_1persona.html#a8fbbb6370fe0ec84b3903f06085e39bb',1,'c_poblacio::persona']]],
  ['individu_2ecc',['individu.cc',['../individu_8cc.html',1,'']]],
  ['individu_2ehh',['individu.hh',['../individu_8hh.html',1,'']]],
  ['individu_5fnom',['individu_nom',['../classc__poblacio.html#a517ddae022bb7affd88a562eb54b225c',1,'c_poblacio']]]
];
