var searchData=
[
  ['ind',['ind',['../structc__poblacio_1_1persona.html#a8fbbb6370fe0ec84b3903f06085e39bb',1,'c_poblacio::persona']]]
];
