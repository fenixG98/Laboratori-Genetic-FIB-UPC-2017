var searchData=
[
  ['mare',['mare',['../structc__poblacio_1_1persona.html#a0ff013e4d5beae801e4e5b10b76880fb',1,'c_poblacio::persona']]]
];
