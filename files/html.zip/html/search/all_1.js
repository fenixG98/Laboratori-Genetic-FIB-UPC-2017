var searchData=
[
  ['c_5fespecie',['c_especie',['../classc__especie.html',1,'c_especie'],['../classc__especie.html#ac9fb949e66ae0fdbd3f09f92d3b598fe',1,'c_especie::c_especie()']]],
  ['c_5findividu',['c_individu',['../classc__individu.html',1,'c_individu'],['../classc__individu.html#a5a7c28e45f6f2bbdba3f42c6a0b9d82e',1,'c_individu::c_individu()'],['../classc__individu.html#a27b79b7c34f39bedd16f9e698b8d93c1',1,'c_individu::c_individu(par_rep &amp;pr, const c_individu &amp;a, const c_individu &amp;b)']]],
  ['c_5fpoblacio',['c_poblacio',['../classc__poblacio.html',1,'c_poblacio'],['../classc__poblacio.html#a04c739d8e073efe94610f7281ceb69f4',1,'c_poblacio::c_poblacio()']]],
  ['cod_5fgen',['COD_GEN',['../classc__individu.html#a008235c688699231e48ce12040cf11f7',1,'c_individu']]],
  ['compatibles',['compatibles',['../classc__poblacio.html#aa2ff825db47e7baca8ae104d13046712',1,'c_poblacio']]],
  ['consultar_5flen_5frep',['consultar_len_rep',['../classpar__rep.html#a3975b2cd48b77ae95fe9a5bb44ba292a',1,'par_rep']]],
  ['consultar_5flongitud_5fi',['consultar_longitud_i',['../classc__especie.html#adc97960e9176e8afee347ff179d3db08',1,'c_especie']]],
  ['consultar_5flongitud_5frepro',['consultar_longitud_repro',['../classc__especie.html#aac788eb75c4c91aeacb9fa8cf53f53ca',1,'c_especie']]],
  ['consultar_5flongitud_5fx',['consultar_longitud_x',['../classc__especie.html#a1d274178b1dbb08b4fcdb5e7fe9e4c3c',1,'c_especie']]],
  ['consultar_5flongitud_5fy',['consultar_longitud_y',['../classc__especie.html#a6b75960550cb95d93a16a2f2680e5b76',1,'c_especie']]],
  ['consultar_5fnom',['consultar_NOM',['../classarbre__parcial.html#a1e19065945c01731d1a976cb11fc67a1',1,'arbre_parcial']]],
  ['consultar_5fnumero_5fparells',['consultar_numero_parells',['../classc__especie.html#aad6a3e8dab81597ee5390185e5c50f84',1,'c_especie']]],
  ['consultar_5fovul_5fesper',['consultar_ovul_esper',['../classpar__rep.html#a4815122f4bcb043639b646d43aac2760',1,'par_rep']]],
  ['consultar_5fpunt_5ftall',['consultar_punt_tall',['../classpar__rep.html#a8d32ed97fdb0b02e8975315e022cc76d',1,'par_rep']]],
  ['consultar_5fsexe',['consultar_SEXE',['../classc__individu.html#aa2048f8741bfd455cd67dbff99311e14',1,'c_individu']]],
  ['creurar_5fllistes',['creurar_llistes',['../classc__individu.html#a0949ae69b604539206979f044d69d911',1,'c_individu']]]
];
