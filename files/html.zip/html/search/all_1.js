var searchData=
[
  ['c_5fespecie',['c_especie',['../classc__especie.html',1,'c_especie'],['../classc__especie.html#ac9fb949e66ae0fdbd3f09f92d3b598fe',1,'c_especie::c_especie()']]],
  ['c_5findividu',['c_individu',['../classc__individu.html',1,'c_individu'],['../classc__individu.html#a5a7c28e45f6f2bbdba3f42c6a0b9d82e',1,'c_individu::c_individu()'],['../classc__individu.html#a27b79b7c34f39bedd16f9e698b8d93c1',1,'c_individu::c_individu(par_rep &amp;pr, const c_individu &amp;a, const c_individu &amp;b)']]],
  ['c_5fpoblacio',['c_poblacio',['../classc__poblacio.html',1,'c_poblacio'],['../classc__poblacio.html#a04c739d8e073efe94610f7281ceb69f4',1,'c_poblacio::c_poblacio()']]],
  ['cod_5fgen',['COD_GEN',['../classc__individu.html#a008235c688699231e48ce12040cf11f7',1,'c_individu']]],
  ['compatibles',['compatibles',['../classc__poblacio.html#aa2ff825db47e7baca8ae104d13046712',1,'c_poblacio']]],
  ['consultar_5flen_5frep',['consultar_len_rep',['../classpar__rep.html#a6687c9c046b96435326ab01808e79078',1,'par_rep']]],
  ['consultar_5flongitud_5fi',['consultar_longitud_i',['../classc__especie.html#a56c078fdb4e22b4920bf1ccd1e71b977',1,'c_especie']]],
  ['consultar_5flongitud_5frepro',['consultar_longitud_repro',['../classc__especie.html#a64085e5fced629ec7ec8107d2eb75351',1,'c_especie']]],
  ['consultar_5flongitud_5fx',['consultar_longitud_x',['../classc__especie.html#adf08d6165408bea772e5592546696735',1,'c_especie']]],
  ['consultar_5flongitud_5fy',['consultar_longitud_y',['../classc__especie.html#ad9b5122d9f23c2e97b00bb2bbcad1557',1,'c_especie']]],
  ['consultar_5fnom',['consultar_NOM',['../classarbre__parcial.html#a504acbdc9f60be7fad415af8f8b57403',1,'arbre_parcial']]],
  ['consultar_5fnumero_5fparells',['consultar_numero_parells',['../classc__especie.html#a302ee809781451497cacaf7de09c199c',1,'c_especie']]],
  ['consultar_5fovul_5fesper',['consultar_ovul_esper',['../classpar__rep.html#aae2aa8a29a33693813fe3f9402c97187',1,'par_rep']]],
  ['consultar_5fpunt_5ftall',['consultar_punt_tall',['../classpar__rep.html#a5f6a8effe0673dbb2d2f7d22b8d011bc',1,'par_rep']]],
  ['consultar_5fsexe',['consultar_SEXE',['../classc__individu.html#ad8455429356c00925f5a8d1022924b1a',1,'c_individu']]],
  ['creurar_5fllistes',['creurar_llistes',['../classc__individu.html#a0949ae69b604539206979f044d69d911',1,'c_individu']]]
];
