var searchData=
[
  ['afegir_5findividu',['afegir_individu',['../classc__poblacio.html#a1b427d9576a259978e3fa1f2d8486ce6',1,'c_poblacio']]],
  ['afegir_5fpares',['afegir_pares',['../classc__poblacio.html#afa2b7ff04bc5b5f7d87012dc6c519fae',1,'c_poblacio']]],
  ['arbre_5fgenealogic',['arbre_genealogic',['../classc__poblacio.html#a9e9c3987145f488bcdbb25ffaeb08308',1,'c_poblacio']]],
  ['arbre_5fparcial',['arbre_parcial',['../classarbre__parcial.html#a1da288f72d35df1779355382a5cdfa4f',1,'arbre_parcial::arbre_parcial()'],['../classarbre__parcial.html#a2b9a529c4ba1eb7f65b1803572a42b9c',1,'arbre_parcial::arbre_parcial(const Arbre&lt; string &gt; &amp;copia)']]]
];
