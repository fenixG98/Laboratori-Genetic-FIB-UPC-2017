var searchData=
[
  ['practica_20pro2_3a_20experimentos_20genéticos_20en_20laboratorio_2e',['Practica PRO2: Experimentos genéticos en laboratorio.',['../index.html',1,'']]],
  ['par_5frep',['par_rep',['../classpar__rep.html',1,'par_rep'],['../classpar__rep.html#a0adfc8dfec60921e0be13d50998dea74',1,'par_rep::par_rep()']]],
  ['parametres_5frepro_2ecc',['parametres_repro.cc',['../parametres__repro_8cc.html',1,'']]],
  ['parametres_5frepro_2ehh',['parametres_repro.hh',['../parametres__repro_8hh.html',1,'']]],
  ['pare',['pare',['../structc__poblacio_1_1persona.html#afbd1c01c19c8140b967340a228b87429',1,'c_poblacio::persona']]],
  ['persona',['persona',['../structc__poblacio_1_1persona.html',1,'c_poblacio']]],
  ['poblacio_2ecc',['poblacio.cc',['../poblacio_8cc.html',1,'']]],
  ['poblacio_2ehh',['poblacio.hh',['../poblacio_8hh.html',1,'']]],
  ['pr',['pr',['../classpar__rep.html#a20decee5a9ce0228930bf2dfcba7dd7e',1,'par_rep']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
