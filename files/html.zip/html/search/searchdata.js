var indexSectionsWithContent =
{
  0: "acefilmnprstv~",
  1: "acp",
  2: "aeip",
  3: "acefilmprt~",
  4: "acilmnpsv",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Páginas"
};

