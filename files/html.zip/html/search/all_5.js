var searchData=
[
  ['l',['l',['../classc__especie.html#aa01789704c32c790cf5e437c906f17ca',1,'c_especie']]],
  ['lenrep',['lenRep',['../classpar__rep.html#a78abfa6a9f3282ebcd781b774092a055',1,'par_rep']]],
  ['llegir',['llegir',['../classarbre__parcial.html#af8230b81c116154ca14617eadca6df72',1,'arbre_parcial::llegir()'],['../classc__especie.html#a6d052db3ee7e9fe608d56e0968abe4c2',1,'c_especie::llegir()'],['../classc__individu.html#af02ba9ffc740f72c9522cff55bf33c04',1,'c_individu::llegir()'],['../classc__poblacio.html#a8a12266f7dc926a26aa5f81e3fa907d6',1,'c_poblacio::llegir()']]],
  ['llegir_5farbre_5fstring',['llegir_arbre_string',['../classarbre__parcial.html#a0edfb52afc039f619ef7fac95f0bcbbb',1,'arbre_parcial']]],
  ['llegir_5fparametres_5freproduccio',['llegir_parametres_reproduccio',['../classpar__rep.html#aca2f847ff7c0aeed517f023e706845bb',1,'par_rep']]],
  ['lx',['lx',['../classc__especie.html#ad84b2081e35c7d5afcc71c4cb9cb1f69',1,'c_especie']]],
  ['ly',['ly',['../classc__especie.html#a05e75f991ce2bf074c2f7399f5fc17ed',1,'c_especie']]]
];
