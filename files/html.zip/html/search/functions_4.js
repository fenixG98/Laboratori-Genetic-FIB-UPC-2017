var searchData=
[
  ['individu_5fnom',['individu_nom',['../classc__poblacio.html#a517ddae022bb7affd88a562eb54b225c',1,'c_poblacio']]]
];
