var searchData=
[
  ['individu_5fnom',['individu_nom',['../classc__poblacio.html#a69739693a38ebd94fcd78b05bd317cf3',1,'c_poblacio']]]
];
