var searchData=
[
  ['amb_5fpares',['amb_pares',['../classc__individu.html#a42adb1ea4fb2ff5a3b2a74c4208c5ba8',1,'c_individu']]],
  ['ap',['ap',['../classarbre__parcial.html#a2608c2126d9719da14c5dc435e77e029',1,'arbre_parcial']]]
];
