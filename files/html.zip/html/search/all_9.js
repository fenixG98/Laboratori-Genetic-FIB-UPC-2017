var searchData=
[
  ['r_5farbre_5fgenealogic',['r_arbre_genealogic',['../classc__poblacio.html#aa5432a28cb41356e18e8ab6fdab050cc',1,'c_poblacio']]],
  ['r_5fcomprobar_5fascendent',['r_comprobar_ascendent',['../classc__poblacio.html#a4c17b6bc2943f0bbf9354929113f0f33',1,'c_poblacio']]],
  ['r_5fes_5fparcial',['r_es_parcial',['../classarbre__parcial.html#a034ec03c0d4ac03766ce5ef36c8bce10',1,'arbre_parcial']]],
  ['r_5fgenerar_5farbre_5fgenealogic',['r_generar_arbre_genealogic',['../classc__poblacio.html#abff633b72a1c45ae0ee0d6649e929dcb',1,'c_poblacio']]]
];
