var searchData=
[
  ['vind',['vind',['../classc__poblacio.html#a40421c00badfa2870eb8d91800de0960',1,'c_poblacio']]]
];
