var searchData=
[
  ['llegir',['llegir',['../classarbre__parcial.html#af8230b81c116154ca14617eadca6df72',1,'arbre_parcial::llegir()'],['../classc__especie.html#a6d052db3ee7e9fe608d56e0968abe4c2',1,'c_especie::llegir()'],['../classc__individu.html#af02ba9ffc740f72c9522cff55bf33c04',1,'c_individu::llegir()'],['../classc__poblacio.html#a8a12266f7dc926a26aa5f81e3fa907d6',1,'c_poblacio::llegir()']]],
  ['llegir_5farbre_5fstring',['llegir_arbre_string',['../classarbre__parcial.html#a0edfb52afc039f619ef7fac95f0bcbbb',1,'arbre_parcial']]],
  ['llegir_5fparametres_5freproduccio',['llegir_parametres_reproduccio',['../classpar__rep.html#aca2f847ff7c0aeed517f023e706845bb',1,'par_rep']]]
];
