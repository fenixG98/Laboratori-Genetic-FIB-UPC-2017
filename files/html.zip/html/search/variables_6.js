var searchData=
[
  ['pare',['pare',['../structc__poblacio_1_1persona.html#afbd1c01c19c8140b967340a228b87429',1,'c_poblacio::persona']]],
  ['pr',['pr',['../classpar__rep.html#a20decee5a9ce0228930bf2dfcba7dd7e',1,'par_rep']]]
];
