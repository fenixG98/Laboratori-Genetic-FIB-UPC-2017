var searchData=
[
  ['par_5frep',['par_rep',['../classpar__rep.html',1,'']]],
  ['persona',['persona',['../structc__poblacio_1_1persona.html',1,'c_poblacio']]]
];
